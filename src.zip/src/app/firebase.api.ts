export const config = {
  apiKey: "AIzaSyBPnpiKWxzG8lzZ-gVtOHxOtYoTmLvSigI",
  authDomain: "pwrdbld.firebaseapp.com",
  databaseURL: "https://pwrdbld.firebaseio.com",
  projectId: "pwrdbld",
  storageBucket: "pwrdbld.appspot.com",
  messagingSenderId: "537786164486"
};