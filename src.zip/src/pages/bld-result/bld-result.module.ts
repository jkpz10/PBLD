import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BldResultPage } from './bld-result';

@NgModule({
  declarations: [
    BldResultPage,
  ],
  imports: [
    IonicPageModule.forChild(BldResultPage),
  ],
})
export class BldResultPageModule {}
